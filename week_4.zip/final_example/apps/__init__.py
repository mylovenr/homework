from flask import Flask
import os

app = Flask('apps')

import views